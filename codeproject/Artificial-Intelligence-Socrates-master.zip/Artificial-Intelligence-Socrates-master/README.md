# Artificial-Intelligence-Socrates
‘Expert Systems’ is one of the most commercially successful application of Artificial Intelligence. This code base shows how to develop an expert system based artificial advisor, using a backward reasoning algorithm.

Check out my detailed step by step guide on how to develop this AI application using CLIPS in C++, Java and C#.
http://www.codeproject.com/Articles/179375/Man-Marriage-and-Machine-Adventures-in-Artificial

